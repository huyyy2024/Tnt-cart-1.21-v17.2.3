package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FireBowRuntime v5 — corrected tick ordering.
 *
 * Tick N   (arrow tick):  scheduleRailPlacement → prepareRailPlacement → setPendingTarget
 * Tick N+1 (client tick): beforeSync() → applyBeforeSync() → movement packet [rot]
 *                         executePending() → wasApplied()=true → interactBlock [rot]
 *                         → Grim: movement packet và interact cùng rotation, cùng tick → pass
 *
 * Cart: check hasRail mỗi tick, đặt ngay khi true (HT1 speed).
 */
public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_TTL = 3000L;

    private final Set<BlockPos> recentDone =
        Collections.newSetFromMap(new ConcurrentHashMap<>());

    // pendingCarts: pos → [ticksLeft, retries]
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_RETRY = 10;

    private volatile boolean railPrepared = false;
    private volatile boolean enabled      = true;

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }

    // ─── Dedup ───────────────────────────────────────────────────────────────

    public boolean isDuplicateArrow(int id) {
        Long t = acceptedArrows.get(id);
        return t != null && (System.currentTimeMillis() - t) < ARROW_TTL;
    }

    public boolean wasRecentlyPlaced(BlockPos pos) {
        return recentDone.contains(pos);
    }

    // ─── Phase 1: Arrow tick → schedule ─────────────────────────────────────

    public void scheduleRailPlacement(MinecraftClient mc, int arrowId,
                                      BlockPos railPos, int railSlot) {
        if (recentDone.contains(railPos)) return;
        if (railPrepared || InteractionUtil.hasPending()) return;

        InteractionUtil.prepareRailPlacement(mc, railPos, railSlot);
        railPrepared = true;

        acceptedArrows.put(arrowId, System.currentTimeMillis());
        recentDone.add(railPos);
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(arrowId), ARROW_TTL);
    }

    // ─── Phase 2: beforeSync tick N+1 → apply rotation ──────────────────────

    /**
     * Inject ở HEAD của sendMovementPackets — chạy TRƯỚC khi packet serialize.
     * Rotation được tính từ eyePos tick N+1 (eyePos hiện tại tại thời điểm này).
     * → movement packet tick N+1 mang rotation đúng.
     */
    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (RotationUtil.applyBeforeSync(mc.player)) {
            // Force gửi movement packet ngay với rotation mới
            // Đảm bảo packet đi TRƯỚC interactBlock trong cùng tick này
            mc.player.networkHandler.sendPacket(
                new net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.Full(
                    mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                    mc.player.getYaw(), mc.player.getPitch(),
                    mc.player.isOnGround()
                )
            );
        }
    }

    // ─── Phase 3: onClientTick tick N+1 → execute ───────────────────────────

    public void onClientTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        if (!enabled) {
            InteractionUtil.clearPending();
            pendingCarts.clear();
            railPrepared = false;
            return;
        }

        // executePending chạy SAU beforeSync trong cùng tick N+1
        // wasApplied() = true đảm bảo movement packet đã mang rotation
        if (railPrepared && InteractionUtil.hasPending()) {
            boolean done = InteractionUtil.executePending(mc);
            if (done) {
                railPrepared = false;
            }
            // Nếu wasApplied()=false (beforeSync chưa chạy tick này) → thử lại tick sau
        }

        processPendingCarts(mc);
    }

    // ─── Cart ────────────────────────────────────────────────────────────────

    private void processPendingCarts(MinecraftClient mc) {
        if (pendingCarts.isEmpty()) return;

        Iterator<Map.Entry<BlockPos, int[]>> iter = pendingCarts.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<BlockPos, int[]> e = iter.next();
            BlockPos pos   = e.getKey();
            int[]    state = e.getValue(); // [ticksLeft, retries]

            state[0]--;
            if (state[0] > 0) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                iter.remove();
                recentDone.remove(pos); // cho phép bắn lại vị trí này
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing()) {
                    InteractionUtil.placeCartDirect(mc, pos, cart.slot);
                }
                return;
            } else if (state[1] < MAX_RETRY) {
                // Backoff: 1, 2, 4, 8, 8... tick
                int backoff = Math.min(1 << state[1], 8);
                state[0] = backoff;
                state[1]++;
            } else {
                iter.remove();
                recentDone.remove(pos);
            }
        }
    }

    public void scheduleCartPlacement(BlockPos railPos, long pingMs) {
        // Delay 1 tick — check hasRail ngay từ tick tiếp theo
        // HT1: đặt cart ngay khi client thấy rail, không chờ cứng
        pendingCarts.put(railPos, new int[]{ 1, 0 });
    }
}
