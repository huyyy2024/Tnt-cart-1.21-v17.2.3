package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.InteractionUtil;
import com.firebow.util.PlacementCalc;
import com.firebow.util.PingUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    @Unique private int firebow$age = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        firebow$age++;
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;
        if (mc.player == null || mc.interactionManager == null) return;
        if (self.getVelocity().lengthSquared() < 0.0001) return;
        if (firebow$age > 60) return;

        int entityId = self.getId();
        if (rt.isDuplicateArrow(entityId)) return;

        Vec3d pos  = self.getPos();
        Vec3d vel  = self.getVelocity();
        World world = self.getWorld();

        // Luôn dùng real-time predict từ velocity arrow tại tick này
        // Precomputed từ bow release bị loại bỏ — stale khi player di chuyển
        int ticksLeft = ticksToLand(pos, vel, world);
        if (ticksLeft < 0 || ticksLeft > 25) return; // quá xa hoặc không tìm được

        BlockPos railPos = PlacementCalc.predictLandingRailPos(world, pos, vel);
        if (railPos == null) return;

        Vec3d eye    = mc.player.getEyePos();
        Vec3d velP   = mc.player.getVelocity();
        double vy    = mc.player.isOnGround() ? velP.y : (velP.y - 0.08) * 0.98;
        Vec3d eyeNext = eye.add(velP.x, vy, velP.z);
        Vec3d center  = Vec3d.ofCenter(railPos);

        double distCur  = eye.squaredDistanceTo(center);
        double distNext = eyeNext.squaredDistanceTo(center);
        if (Math.max(distCur, distNext) > 4.5 * 4.5) return;
        if (distNext < 1.0) return;
        if (rt.wasRecentlyPlaced(railPos)) return;

        // Kiểm tra inventory
        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        // Phase 1: schedule rail placement (2-tick pattern)
        // KHÔNG interact trực tiếp — chuẩn bị rotation + pending
        rt.scheduleRailPlacement(mc, entityId, railPos, target.railSlot.slot);

        // Schedule cart sau khi rail placed
        long ping = PingUtil.getPingMs(mc);
        rt.scheduleCartPlacement(railPos, ping);
    }

    /**
     * Simulate đầy đủ physics để đếm tick còn lại đến khi tên chạm block.
     * Trả về số tick, hoặc -1 nếu không tìm được trong 120 tick.
     */
    private int ticksToLand(Vec3d pos, Vec3d vel, World world) {
        double x = pos.x, y = pos.y, z = pos.z;
        double vx = vel.x, vy = vel.y, vz = vel.z;
        for (int i = 0; i < 120; i++) {
            vy -= 0.05;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;
            BlockPos cur   = BlockPos.ofFloored(x, y, z);
            BlockPos below = cur.down();
            if (!world.getBlockState(cur).isAir()) return i;
            if (!world.getBlockState(below).isAir()
                    && PlacementCalc.isSolidGround(world, below)
                    && world.getBlockState(cur).isAir()) return i;
        }
        return -1;
    }

    private boolean isOwnArrow(PersistentProjectileEntity a, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = a.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
